raw2db is a little utility which allow you to convert
hex into ascii (db,dw,dd,dq) for using in you asm source.
It's just easy to use.. the output default extension is .txt
Enjoy ;)

Note: Report bugs, comments.. at lucifer48@yahoo.com

What's new ?
------------
v1.0 - 08/08/2000
 * First version
v1.01 - 08/21/2000
 * Fixed the DD tiny bug ;)
 * Bug: cmp eax,-1 instead of test eax,eax (after CreateFileA)
 * Added an end-job messagebox
 * Added "0x" option (C/res syntax)
 * Added "end of line" feature
v1.02 - 08/27/2001
 * Added "Big endian" checkbox
 * Added "dq" quantity

Known bugs
----------
 * Don't use "dq" and "%d" together

______________________________________________________________________________________________ 
Lucifer48 [Phrozen Crew], August 2001
http://lucifer48.cjb.net